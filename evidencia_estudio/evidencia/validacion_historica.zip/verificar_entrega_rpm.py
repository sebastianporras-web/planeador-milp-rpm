"""Control independiente de las 1.000 soluciones guardadas y de sus cotas."""
from validacion_rpm_20260923 import *

data,audit=getdata();C=data['cij'].to_numpy();S=data['setup'].to_numpy()
demands=pd.read_csv(OUT/'monte_carlo_demandas.csv',index_col=0).to_numpy()
rows=pd.read_csv(OUT/'monte_carlo_escenarios.csv')
assert len(rows)==1000 and rows.escenario.nunique()==1000
maxima={k:0. for k in ['demanda','capacidad','integralidad','enlace','objetivo','dominio','diferencia_demanda_guardada']}
missing=[];violations=[]
for _,r in rows.iterrows():
    number=int(r.escenario);file=OUT/'mc_planes'/f'{number:04d}.npz'
    if not file.exists():missing.append(number);continue
    z=np.load(file);X=z['X'][:,:,0];Y=z['Y'][:,:,0];D=z['D']
    assert X.shape==(99,10) and Y.shape==(99,10)
    U=np.maximum(0,np.minimum(D[:,None],np.floor((1440-S)[None,:]/C)))
    loads=(C*X+S*Y).sum(axis=0)
    res={'demanda':float(abs(X.sum(axis=1)-D).max()),'capacidad':float(max(0,(loads-1440).max())),'integralidad':float(max(abs(X-np.rint(X)).max(),abs(Y-np.rint(Y)).max())),'enlace':float(max(0,(X-U*Y).max())),'objetivo':float(abs(loads.sum()-r.objective)),'dominio':float(max(0,-X.min(),-Y.min(),Y.max()-1)),'diferencia_demanda_guardada':float(abs(D-demands[number-1]).max())}
    for k,v in res.items():maxima[k]=max(maxima[k],v)
    if max(res.values())>1e-6:violations.append({'escenario':number,**res})
    assert r.lower_bound<=r.objective+1e-5
    if not r.heuristica_faltantes:
        lo=100*(1-r.objective/r.heuristica_objetivo);hi=100*(1-r.lower_bound/r.heuristica_objetivo)
        assert abs(lo-r.mejora_incumbente_pct)<1e-8
        assert abs(hi-r.mejora_cota_superior_pct)<1e-8
savejson('verificacion_independiente_1000.json',{'n_escenarios':len(rows),'sin_archivo_plan':missing,'violaciones':violations,'residuos_maximos':maxima,'logs':len(list((OUT/'mc_logs').glob('*.log'))),'tolerancia':1e-6})
assert not missing and not violations
print('Control independiente aprobado',maxima)
