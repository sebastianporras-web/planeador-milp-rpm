from validacion_rpm_20260923 import *

data,audit=getdata();D=demanda_entera(data['demanda'])
ext=cargar_datos_extendido(SOURCE/'AnexodeDatosxlsx.xlsx')
cal=calibrar_demanda_extendida(D,ext['demanda']);C=ext['cij'];S=ext['setup'];dh=demanda_entera(cal['demanda_calibrada'],factor=3)
plan=pd.read_csv(SOURCE/'results/multiday_plan_final.csv')
plan.producto=plan.producto.astype(str).str.strip()
assert plan.producto.isin(C.index).all() and plan.maquina.isin(MACHINES).all()
assert not plan.duplicated(['producto','maquina','dia']).any()
quant=plan.groupby('producto').unidades.sum().reindex(dh.index,fill_value=0)
plan['C']= [C.loc[i,j] for i,j in zip(plan.producto,plan.maquina)]
plan['S']=plan.maquina.map(S)
plan['minutos']=plan.C*plan.unidades+plan.S
load=plan.groupby(['dia','maquina']).minutos.sum()
check={'objective':float(plan.minutos.sum()),'production':float((plan.C*plan.unidades).sum()),'setup':float(plan.S.sum()),'demand_residual':float((quant-dh).abs().max()),'capacity_excess':float(max(0,load.max()-1440)),'integrality_residual':float(np.abs(plan.unidades-np.rint(plan.unidades)).max()),'demand_total':int(plan.unidades.sum()),'active_pairs':len(plan),'days_valid':bool(plan.dia.isin([1,2,3]).all()),'positive_units':bool((plan.unidades>0).all())}
check['feasible']=check['demand_residual']<=1e-6 and check['capacity_excess']<=1e-6 and check['integrality_residual']<=1e-6 and check['days_valid'] and check['positive_units']
counts=plan.groupby(['dia','maquina']).size().unstack(fill_value=0).reindex(columns=MACHINES,fill_value=0)
oldcounts=pd.read_csv(SOURCE/'results/multiday_setups_final.csv',index_col=0)
check['setups_counts_match']=bool(counts.eq(oldcounts).all().all())
savejson('verificacion_plan_multidia_guardado.json',check)
plan.to_csv(OUT/'verificacion_plan_multidia_guardado.csv',index=False)
print(check,flush=True)
ds=demanda_entera(cal['demanda_calibrada'])
r,X,Y,L=solve(C,ds,S,days=1,limit=60,gap=.005,disp=True)
r['demanda_total']=int(ds.sum());export_solution('multidia_demanda_proporcional_1dia',C,ds,S,r,X,Y,L)
