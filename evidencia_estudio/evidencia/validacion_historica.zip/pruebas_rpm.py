from validacion_rpm_20260923 import *
import itertools

tests=[]
for demand,cap in [([2,3],[8,8]),([2,3],[3,3]),([1,1],[10,10])]:
    C=np.array([[1.,3.],[2.,1.]]);S=np.array([1.,2.]);best=np.inf
    for q in itertools.product(*[range(d+1) for d in demand]):
        X=np.array([[q[i],demand[i]-q[i]] for i in range(2)])
        Y=X>0;load=(X*C+Y*S).sum(axis=0)
        if (load<=np.array(cap)+1e-9).all():best=min(best,load.sum())
    r,*_=solve(C,demand,S,caps=cap,limit=5)
    ok=(not np.isfinite(best) and r['status']==2) or (np.isfinite(best) and r['feasible'] and abs(r['objective']-best)<1e-8)
    assert ok,(best,r)
    tests.append({'demanda':demand,'capacidad':cap,'enumeracion_exhaustiva_objetivo':None if not np.isfinite(best) else best,'milp_objetivo':r['objective'],'ok':bool(ok)})
savejson('pruebas_unitarias_formulacion.json',tests)
print(tests)
