"""Revalidación independiente. No modifica datos ni tesis. Python/SciPy/HiGHS."""
from pathlib import Path
import ast, math, json, time, hashlib, platform, argparse, warnings
import os
from concurrent.futures import ProcessPoolExecutor
from typing import Iterable
import numpy as np
import pandas as pd
import scipy
from scipy import stats
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'audit_run'
OUT = ROOT/'validacion_rpm_resultados'
OUT.mkdir(exist_ok=True)
MACHINES = [f'M{i}' for i in range(1,11)]
CAP_MINUTOS_DIA=1440
TOL=1e-6
# Reutilizar funciones puras del código recibido sin importar PuLP no disponible.
NAMES = {'_cargar_setup','cargar_datos','construir_cij_con_imputacion',
 'comparar_matriz_publicada_reconstruida','validacion_imputacion_repetida',
 'cargar_datos_extendido','calibrar_demanda_extendida','demanda_entera',
 '_validar_demanda_entera','_serie_capacidades','politica_empirica'}
tree=ast.parse((SOURCE/'rpm_core.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in NAMES],type_ignores=[]),str(SOURCE/'rpm_core.py'),'exec'))

def savejson(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,'item') else str(x)))

def solve(C,D,S,caps=1440,days=1,limit=30,gap=0,disp=False):
    C=np.asarray(C,float);D=np.asarray(D,float);S=np.asarray(S,float)
    n,m=C.shape; caps=np.broadcast_to(np.asarray(caps,float),(m,))
    assert np.all(np.isfinite(C)) and np.all(C>0)
    assert np.max(np.abs(D-np.rint(D)))<1e-8
    costs=np.repeat(C[:,:,None],days,axis=2).ravel()
    setups=np.broadcast_to(S[None,:,None],(n,m,days)).ravel()
    K=len(costs); ind=np.arange(K); ii=np.repeat(np.arange(n),m*days)
    jt=np.tile(np.arange(m*days),n)
    U=np.maximum(0,np.minimum(D[:,None],np.floor((caps-S)[None,:]/C)))
    U=np.repeat(U[:,:,None],days,axis=2).ravel()
    rr=np.r_[ii,n+jt,n+jt,n+m*days+ind,n+m*days+ind]
    cc=np.r_[ind,ind,K+ind,ind,K+ind]
    vv=np.r_[np.ones(K),costs,setups,np.ones(K),-U]
    A=coo_matrix((vv,(rr,cc)),shape=(n+m*days+K,2*K)).tocsc()
    con=LinearConstraint(A,np.r_[D,np.full(m*days+K,-np.inf)],np.r_[D,np.repeat(caps,days),np.zeros(K)])
    t=time.monotonic()
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',message='Unrecognized options detected')
        res=milp(np.r_[costs,setups],integrality=np.ones(2*K),bounds=Bounds(np.zeros(2*K),np.r_[U,np.ones(K)]),constraints=con,options={'time_limit':limit,'mip_rel_gap':gap,'disp':disp,'threads':1,'random_seed':42})
    r={'status':int(res.status),'message':res.message,'seconds':time.monotonic()-t,'limit_s':limit,'requested_gap':gap,'objective':None,'lower_bound':None,'gap_pct':None,'feasible':False,'certified_zero_gap':False}
    for a,b in [('fun','objective'),('mip_dual_bound','lower_bound'),('mip_gap','gap_pct'),('mip_node_count','nodes')]:
        val=getattr(res,a,None)
        if val is not None:r[b]=float(val)*(100 if b=='gap_pct' else 1)
    if res.x is not None:
        raw=res.x;X=raw[:K].reshape(n,m,days);Y=raw[K:].reshape(n,m,days)
        loads=(X*C[:,:,None]+Y*S[None,:,None]).sum(axis=0)
        r.update(demand_residual=float(np.max(np.abs(X.sum(axis=(1,2))-D))),capacity_excess=float(max(0,np.max(loads-caps[:,None]))),link_excess=float(max(0,np.max(raw[:K]-U*raw[K:]))),integrality_residual=float(np.max(np.abs(raw-np.rint(raw)))),bound_excess=float(max(0,-np.min(raw),np.max(raw[K:]-1))),objective_residual=float(abs(np.dot(np.r_[costs,setups],raw)-res.fun)))
        r['feasible']=all(r[k]<=1e-6 for k in ['demand_residual','capacity_excess','link_excess','integrality_residual','bound_excess','objective_residual'])
        r['certified_zero_gap']=r['feasible'] and res.status==0 and r['gap_pct'] is not None and r['gap_pct']<=1e-7
        r.update(production_min=float((X*C[:,:,None]).sum()),setup_min=float((Y*S[None,:,None]).sum()),active_pairs=int(np.sum(X>0.5)),implied_setups=int(np.rint(Y).sum()))
        return r,X,Y,loads
    return r,None,None,None

def export_solution(tag,C,D,S,r,X,Y,loads):
    savejson(tag+'.json',r)
    if X is not None:
        rows=[]
        for i,p in enumerate(C.index):
            for j,m in enumerate(C.columns):
                for t in range(X.shape[2]):
                    rows.append([p,m,t+1,float(X[i,j,t]),float(Y[i,j,t]),float(C.iloc[i,j]),float(S.iloc[j])])
        pd.DataFrame(rows,columns=['referencia','maquina','dia','X_sin_redondear','Y_sin_redondear','C_min_unidad','S_min']).to_csv(OUT/(tag+'_plan.csv'),index=False)
        pd.DataFrame(loads,index=C.columns).to_csv(OUT/(tag+'_carga.csv'))
    print(tag,json.dumps(r,ensure_ascii=False),flush=True)

def getdata():
    data=cargar_datos(SOURCE/'AnexodeDatosxlsx.xlsx')
    audit=construir_cij_con_imputacion(SOURCE/'AnexodeDatosxlsx.xlsx',data['cij'].index)
    return data,audit

def base():
    data,audit=getdata();C=data['cij'];D=demanda_entera(data['demanda']);S=data['setup']
    for name,mat in [('publicada',C),('reconstruida',audit['cij']),('observada',audit['cij_observada']),('mascara_observada',audit['mask_observado'])]:mat.to_csv(OUT/('matriz_'+name+'.csv'))
    D.to_csv(OUT/'demanda_base.csv');S.to_csv(OUT/'setup.csv')
    diff=[]
    for i,p in enumerate(C.index):
        for j,m in enumerate(C.columns):
            a=C.iloc[i,j];b=audit['cij'].iloc[i,j]
            diff.append([p,m,a,b,abs(a-b),bool(audit['mask_observado'].iloc[i,j]),abs(a-b)>1e-6])
    pd.DataFrame(diff,columns=['referencia','maquina','publicada','reconstruida','diferencia_abs','observada','difiere_1e6']).to_csv(OUT/'comparacion_990_celdas.csv',index=False)
    savejson('comparacion_matrices.json',comparar_matriz_publicada_reconstruida(C,audit))
    solutions={}
    for tag,mat in [('nominal_publicada',C),('nominal_reconstruida',audit['cij'])]:
        r,X,Y,L=solve(mat,D,S,limit=60,disp=True)
        h=politica_empirica(mat,D,S)
        r['heuristica_objetivo']=h['valor_objetivo'];r['heuristica_unidades_faltantes']=int(h['demanda_incumplida'].sum())
        r['mejora_pct']=(1-r['objective']/h['valor_objetivo'])*100 if r['feasible'] and not len(h['demanda_incumplida']) else None
        if X is not None:r['unidades_en_celdas_imputadas']=float((X[:,:,0]*(~audit['mask_observado'].to_numpy())).sum())
        export_solution(tag,mat,D,S,r,X,Y,L);solutions[tag]=(r,X,Y,L)
    x=solutions['nominal_publicada'][1];y=solutions['nominal_reconstruida'][1]
    if x is not None and y is not None:
        changes=pd.DataFrame({'referencia':C.index,'asignacion_cambia':np.any(abs(x[:,:,0]-y[:,:,0])>1e-5,axis=1),'maquina_publicada':np.argmax(x[:,:,0],axis=1)+1,'maquina_reconstruida':np.argmax(y[:,:,0],axis=1)+1})
        changes.to_csv(OUT/'cambios_asignacion.csv',index=False)
        # Evaluación cruzada del plan fijo, sin reoptimizar.
        lx=(x[:,:,0]*audit['cij'].to_numpy()+solutions['nominal_publicada'][2][:,:,0]*S.to_numpy()).sum(axis=0)
        savejson('plan_publicado_evaluado_reconstruida.json',{'objetivo':float(lx.sum()),'max_exceso_capacidad':float(max(0,lx.max()-1440)),'cargas':dict(zip(MACHINES,lx.tolist())),'referencias_cambian':int(changes.asignacion_cambia.sum())})
    val=validacion_imputacion_repetida(SOURCE/'AnexodeDatosxlsx.xlsx',C.index)
    val['resumen'].to_csv(OUT/'imputacion_resumen.csv',index=False);val['detalle'].to_csv(OUT/'imputacion_100_repeticiones.csv',index=False)
    savejson('entorno.json',{'python':platform.python_version(),'scipy':scipy.__version__,'numpy':np.__version__,'pandas':pd.__version__,'solver':'HiGHS 1.8.0 incluido en SciPy','seed':42,'threads_por_solver':1,'hashes_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE/'rpm_core.py',SOURCE/'AnexodeDatosxlsx.xlsx']}})

def mc_job(args):
    number,C,D,S=args[:4]
    limit=args[4] if len(args)>4 else 5
    log=OUT/'mc_logs'/f'{number:04d}.log'
    with open(log,'w') as fh:
        old=os.dup(1);os.dup2(fh.fileno(),1)
        try:r,X,Y,L=solve(C,D,S,limit=limit,gap=0.0001,disp=True)
        finally:os.dup2(old,1);os.close(old)
    ds=pd.Series(D,index=C.index)
    h=politica_empirica(C,ds,S)
    r.update(escenario=number,demanda_total=int(D.sum()),heuristica_objetivo=h['valor_objetivo'],heuristica_faltantes=int(h['demanda_incumplida'].sum()))
    if r['feasible'] and r['heuristica_faltantes']==0:
        r['mejora_incumbente_pct']=(1-r['objective']/h['valor_objetivo'])*100
        r['mejora_cota_superior_pct']=(1-r['lower_bound']/h['valor_objetivo'])*100
    if X is not None:np.savez_compressed(OUT/'mc_planes'/f'{number:04d}.npz',X=X,Y=Y,D=D)
    savejson(f'mc_logs/{number:04d}.json',r)
    return r

def montecarlo(n=1000):
    data,audit=getdata();C=data['cij'];D=demanda_entera(data['demanda']);S=data['setup']
    (OUT/'mc_logs').mkdir(exist_ok=True);(OUT/'mc_planes').mkdir(exist_ok=True)
    rng=np.random.default_rng(42)
    demands=np.maximum(1,np.floor(D.to_numpy()[None,:]*rng.uniform(.85,1.15,(n,len(D)))+.5)).astype(int)
    pd.DataFrame(demands,columns=C.index).to_csv(OUT/'monte_carlo_demandas.csv',index_label='escenario_indice_0')
    with ProcessPoolExecutor(max_workers=4) as pool:
        rows=[]
        for r in pool.map(mc_job,[(i+1,C,demands[i],S) for i in range(n)]):
            rows.append(r)
            if len(rows)%25==0:
                pd.DataFrame(rows).to_csv(OUT/'monte_carlo_escenarios.csv',index=False)
                print('MONTE_CARLO',len(rows),'/',n,flush=True)
    df=pd.DataFrame(rows);df.to_csv(OUT/'monte_carlo_escenarios.csv',index=False)
    valid=df[df.feasible & (df.heuristica_faltantes==0)]
    lo=valid.mejora_incumbente_pct;hi=valid.mejora_cota_superior_pct
    result={'n':n,'n_factibles_milp':int(df.feasible.sum()),'n_gap_cero':int(df.certified_zero_gap.sum()),'n_heuristica_infactible':int((df.heuristica_faltantes>0).sum()),'n_comparables':len(valid),'mean_incumbent_improvement_pct':float(lo.mean()),'mean_optimal_improvement_upper_bound_pct':float(hi.mean()),'median_incumbent_pct':float(lo.median()),'sd_incumbent_pct':float(lo.std(ddof=1)),'min_incumbent_pct':float(lo.min()),'max_incumbent_pct':float(lo.max()),'max_gap_pct':float(df.gap_pct.max()),'mean_gap_pct':float(df.gap_pct.mean()),'seed':42,'matrix':'MODELO PL','time_limit_per_scenario':5,'target_gap_pct':.01,'n_positive_incumbent_improvement':int((lo>0).sum())}
    if len(valid)>1:
        se=lo.std(ddof=1)/np.sqrt(len(lo));q=stats.t.ppf(.975,len(lo)-1)
        result['ci95_mean_incumbent_pct']=[float(lo.mean()-q*se),float(lo.mean()+q*se)]
    savejson('monte_carlo_resumen.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)

def sensitivity():
    data,audit=getdata();D=demanda_entera(data['demanda']);S=data['setup'];rows=[]
    for matrix,C in [('publicada',data['cij']),('reconstruida',audit['cij'])]:
        for j in range(10):
            caps=np.full(10,1440.);caps[j]+=30
            tag=f'capacidad_{matrix}_{MACHINES[j]}'
            r,X,Y,L=solve(C,D,S,caps=caps,limit=15,gap=0.00001)
            export_solution(tag,C,D,S,r,X,Y,L);rows.append(dict(experimento=tag,**r))
    C=data['cij']
    for f in [.8,.9,1.1,1.2]:
        ds=demanda_entera(D,factor=f);tag=f'demanda_{f}'
        r,X,Y,L=solve(C,ds,S,limit=20,gap=0.00001)
        h=politica_empirica(C,ds,S);r.update(heuristica_objetivo=h['valor_objetivo'],heuristica_faltantes=int(h['demanda_incumplida'].sum()),demanda_total=int(ds.sum()))
        export_solution(tag,C,ds,S,r,X,Y,L);rows.append(dict(experimento=tag,**r))
    for f in [.8,1.2]:
        mat=C.where(audit['mask_observado'],C*f);tag=f'imputacion_{f}'
        r,X,Y,L=solve(mat,D,S,limit=20,gap=0.00001)
        export_solution(tag,mat,D,S,r,X,Y,L);rows.append(dict(experimento=tag,**r))
    pd.DataFrame(rows).to_csv(OUT/'sensibilidad.csv',index=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',nargs='?',default='base');p.add_argument('--n',type=int,default=1000);a=p.parse_args()
    if a.mode=='base':base()
    elif a.mode=='mc':montecarlo(a.n)
    elif a.mode=='sens':sensitivity()
