# Resultados de la revalidación y guía de edición manual

Fecha: 23 de septiembre de 2026. No se modificó ningún archivo de la tesis. Esta entrega contiene resultados nuevos, no una reescritura para prometer un porcentaje de detección.

## 1. Decisión editorial que evita mezclar instancias

Mantén 11.547,41 min como resultado de la matriz publicada. Añade la reconstrucción como contraste independiente. No reemplaces globalmente esa cifra por 11.429,98: cambiar de matriz principal exigiría rehacer también caracterización, tablas, figuras, experimentos y conclusiones que dependan de ella.

La conciliación computacional está cerrada en cuanto a magnitud y efectos. La procedencia original de los 171 valores sin observación y la interpretación empresarial de los ceros siguen pendientes. No he escogido una matriz operacional por ti.

## 2. Resultados principales

| Indicador | Publicada | Reconstruida |
|---|---:|---:|
| Objetivo MILP (min) | 11.547,4126 | 11.429,9804 |
| GAP (%) | 0 | 0 |
| Heurística completa (min) | 13.684,4886 | 13.761,0987 |
| Mejora frente a su propia heurística (%) | 15,6168 | 16,9399 |
| Unidades en posiciones no observadas | 1.337 | 227 |
| Pares activos | 99 | 99 |

Los dos planes obtenidos difieren en 21 referencias. Evaluado con los tiempos reconstruidos, el plan publicado consume 11.972,8010 min y sigue siendo factible. Su diferencia respecto al óptimo reconstruido es 542,8206 min. No confundas comparación entre parámetros con ahorro medido en planta.

Solo dos diferencias recaen en pares activos del plan publicado: MAQUILA ENV 1700 TRANSP CAPRI GEN.NUEVO 41 GR SM en M4 (1.337 unidades; impacto de 409,6319 min) y SOBRETAPA VV VERDE SF QUALA en M1 (1.165 unidades; impacto de 15,7565 min). Juntas explican los 425,3884 min añadidos al evaluar ese plan fijo con la reconstrucción. El archivo `diferencias_activas_plan_publicado.csv` conserva el detalle.

### Procedencia de las 174 diferencias

- 171 posiciones no observadas: ninguna coincide con la media por máquina reconstruida a tolerancia 1e-6. No es correcto atribuirlas sin evidencia al método validado.
- SOBRETAPA VV VERDE SF QUALA, M1: el promedio publicado incluye un cero. Pasa de 0,392222 a 0,405747 min/unidad al usar 29 registros positivos.
- ENVASE 4 LTS SUAVIZANTE AZUL PE, M1: contiene 25 ceros y cinco registros positivos. El promedio publicado es 0,075000 y el promedio positivo 0,450000 min/unidad.
- MAQUILA ENV 400 CRISTAL 17 GR S.M. PET CAPRI, M5: los 30 registros positivos y DATOS FINALES dan 0,562222, pero DATOS SIMULADOS y MODELO PL contienen 1,147407 min/unidad. El archivo no explica ese traslado.

Los 990 valores publicados coinciden con DATOS SIMULADOS/60. El nombre de esa hoja no basta para concluir que todas las mediciones sean simuladas. El libro contiene 24.544 entradas positivas para el subconjunto de 99 referencias, contadas como celdas de cronometraje, no como observaciones de campo autenticadas.

### Validación de imputación

Se reprodujeron las 100 particiones de ocultamiento del 20% con semillas 42 a 141: la media por máquina ganó en 96, con MAE medio 0,1887857 min/unidad. Puedes conservar 0,1888 y 96/100. Esta prueba evalúa el estimador sobre celdas observadas ocultadas, no autentica los 171 coeficientes publicados ni garantiza el mecanismo de datos faltantes.

### Capacidad

M8 conserva el mayor beneficio finito en ambas matrices. Para +30 min, su beneficio óptimo está acotado por [5,4161; 5,4983] min en la publicada y [11,4189; 11,5320] min en la reconstruida. El límite inferior de M8 supera todos los límites superiores de las otras máquinas. Los intervalos son cotas del solver, no intervalos de confianza. Consulta `capacidad_intervalos_beneficio.csv` para las diez máquinas.

### Monte Carlo nuevo

- Escenarios solicitados y ejecutados: 1000.
- Planes MILP verificados: 1000.
- Comparaciones con demanda satisfecha por ambos métodos: 1000.
- GAP numéricamente cero: 0 escenarios.
- GAP máximo: 1,1879%.
- Mejora media de los incumbentes: 15,1876%.
- Cota superior de la media óptima de la muestra: 15,2919%.
- Intervalo t aproximado del 95% para la media de los incumbentes: [15,1397%; 15,2355%].

Los 1.000 resultados tienen demanda entera y archivos individuales. Hubo 3 reintentos de 30 segundos por falta de un plan verificable en los primeros cinco segundos. Los límites no garantizan óptimos exactos: reporta las cotas. El intervalo estadístico no incluye automáticamente el error de optimización ni prueba una distribución real de demanda. No reemplaces las figuras históricas por estos números sin regenerarlas. Esta entrega permite mantener la corrida histórica claramente identificada y añadir la nueva como revalidación.

### Multiperiodo: dos preguntas distintas

| Pregunta | Demanda total | Resultado |
|---|---:|---|
| Demanda proporcional, 1 día | 15.328 | Infactibilidad confirmada por HiGHS |
| Demanda proporcional, 2 días | 30.656 | Factible: UB 24.872,3463 min; GAP 1,5037% |
| Lote fijo de tres días, distribuido en 2 | 45.987 | Imposible: cota 29.748,4944 min > capacidad 28.800 min |
| Ese mismo lote fijo en 3 días | 45.987 | Plan previo revalidado: 34.234,8717 min, sin violaciones |

Tres días es mínimo para el lote fijo de 45.987 unidades dentro del modelo. Dos días ya son factibles si la demanda se acumula proporcionalmente al horizonte. No uses una afirmación general de que el catálogo necesita siempre tres días.

La nueva resolución de tres días con 60 segundos obtuvo una solución peor que la conservada. No reemplaces el plan de 34.234,87 min por uno peor: se verificó nuevamente la factibilidad del plan guardado. La cota histórica de CBC sigue identificada como histórica; no se produjo un nuevo log de CBC.

## 3. Dónde colocar cada fragmento en TeXstudio

Haz una copia de tu carpeta antes de editar. Usa Ctrl+F con las etiquetas indicadas. No uses páginas como referencia: pueden cambiar al compilar. Copia el contenido de cada `.tex` de `fragmentos_latex`, no la guía Markdown. Los fragmentos no son documentos autónomos: no los establezcas como archivo principal. En TeXstudio abre tu capítulo, aplica el cambio, guarda con Ctrl+S y compila tu `main.tex`. Si quedan referencias nuevas con interrogantes, compila otra vez. La guía corresponde a la última versión entregada; conserva tus cambios manuales posteriores y usa las etiquetas para localizar cada sección.

| Archivo de tu tesis | Ubicación o texto que debes buscar | Acción | Fragmento |
|---|---|---|---|
| `capitulos/metodologia.tex` | Párrafo que inicia «La reproducción del resultado nominal utiliza» y el siguiente que inicia «La validación de la media por máquina» | Reemplaza ambos párrafos completos | `01_metodologia_matrices.tex` |
| `capitulos/resultados.tex` | Final del capítulo, después de la sección de validación | Añade nueva subsección de revalidación independiente | `02_resultados_matrices.tex` |
| `capitulos/resultados.tex` | Después del fragmento 02 | Añade la comprobación de ranking con cotas | `03_resultados_capacidad.tex` |
| `capitulos/resultados.tex` | Después del fragmento 03 | Añade tablas nuevas de la revalidación, sin mezclar filas de ejecuciones distintas | `04_resultados_sensibilidad.tex` |
| `capitulos/resultados.tex` | Después del fragmento 04 | Añade los dos experimentos de horizonte | `05_resultados_multiperiodo.tex` |
| `capitulos/resultados.tex` | Después del fragmento 05 | Añade la nueva corrida, separada de la histórica | `06_resultados_monte_carlo.tex` |
| `capitulos/limitaciones.tex` | Párrafo que inicia «La matriz publicada y la reconstruida» en `sec:lim-datos` | Sustituye ese párrafo: la comparación y resolución ya no están pendientes | `07_limitaciones_matrices.tex` |
| `capitulos/limitaciones.tex` | Párrafo que inicia «La media de 15,14» en `sec:lim-demanda` | Sustituye ese párrafo, conservando las ecuaciones anteriores | `08_limitaciones_monte_carlo.tex` |
| `capitulos/conclusiones.tex` | Párrafos de comparación de matrices, Monte Carlo e interpretación del horizonte | Sustituye los tres párrafos afectados, distribuyendo los tres del fragmento en los apartados respectivos | `09_conclusiones.tex` |
| `capitulos/reproducibilidad.tex` | Final del apéndice | Añade una subsección; no cambies retrospectivamente la versión de CBC | `10_reproducibilidad.tex` |
| `preliminares/resumen.tex` | Párrafo «Alcance de los datos» | Sustituye ese párrafo | `11_resumen_alcance.tex` |

### Ajustes breves para que no queden contradicciones

1. En metodología, cerca de `eq:imputacion`, aclara que «se utiliza» la media por máquina **en la matriz reconstruida**, no necesariamente en la publicada.
2. En `sec:montecarlo-1000`, conserva la identificación de la corrida antigua como **histórica**. Añade al cierre: «La reejecución con demanda entera y cotas individuales aparece en la Sección~\ref{sec:mc-revalidacion-entera-2026}».
3. En `tab:sintesis`, puedes conservar los resultados antiguos si la fila dice «histórico». Añade otra fila para la revalidación nueva; no pongas su media en la fila histórica.
4. En `tab:factibilidad-horizonte`, no agregues una fila de dos días sin indicar la demanda. Mantén esa tabla como resultados anteriores y remite a la nueva comprobación, o añade una columna «Demanda del horizonte».
5. En conclusiones, elimina la frase «pues no se reporta el caso de dos días»: ya existe esa prueba. Sustituye el párrafo completo con el tercero del fragmento 09.
6. Sustituye la conclusión que empieza «La comprobación documental identificó» con el primer párrafo del fragmento 09. Sustituye los párrafos de Monte Carlo histórico por el segundo, o conserva los históricos con una remisión explícita a la nueva ejecución.
7. En los mapas, figuras y tablas existentes, deja claro qué corresponde a la corrida original. No cambies capturas para que aparenten una nueva ejecución de la app: la revalidación corrió fuera de Streamlit.
8. Si conservas Abstract en inglés, actualiza su párrafo «Data scope» para expresar que la comparación computacional ya se realizó y que la corrida nueva usa demanda entera y cotas. No dejes la afirmación de que la nueva ejecución está pendiente.

Estos añadidos preservan los números anteriores como resultados de su experimento. Si prefieres sustituir todas las tablas antiguas, necesitarás actualizar sus figuras y referencias asociadas. No combines un objetivo de esta corrida con una utilización o GAP de otra.

## 4. Qué sigue pendiente

- Confirmar en planta el significado de los ceros y el origen de los valores trasladados a DATOS SIMULADOS.
- Aprobar la matriz operacional y la compatibilidad física de cada par activo.
- Ejecutar un piloto y comparar contra asignaciones históricas reales, si existen.
- Autenticar observaciones de campo, revisar cada cita contra su fuente y confirmar los datos institucionales.

No se ejecutó un nuevo clustering ni se estimó una distribución de demanda con datos históricos. La revalidación no acredita esas tareas por extensión.

## 5. Respaldo y reproducción

`VALIDACION_RPM_RESULTADOS.zip` incluye código, libro de entrada sin modificar, resultados CSV/JSON, matrices, planes y logs. Cada escenario Monte Carlo conserva su demanda y variables X/Y en NPZ, legibles con NumPy. `entorno.json` registra versiones y huellas SHA-256. El archivo `NOTAS_CODIGO_RPM.md` explica los controles y defectos detectados en el verificador original. `compatibilidad_para_confirmar_en_planta.csv` contiene los 120 pares distintos utilizados entre ambos planes, con campos vacíos para la confirmación empresarial.

Comandos desde la carpeta extraída, con las dependencias instaladas:

```text
python validacion_rpm_20260923.py base
python validacion_rpm_20260923.py sens
python procedencia_rpm.py
python verificar_plan_guardado.py
python pruebas_rpm.py
python validacion_rpm_20260923.py mc --n 1000
python completar_monte_carlo.py
python verificar_entrega_rpm.py
```

Los resultados con límite de tiempo pueden variar entre equipos. Las semillas fijan las demandas, no una trayectoria idéntica de cómputo bajo diferente hardware. Los archivos conservados son la evidencia de esta ejecución.

Documentación oficial de la interfaz de optimización: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html
