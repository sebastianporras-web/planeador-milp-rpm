"""Reintenta solo escenarios sin plan verificable. Conserva los intentos iniciales."""
from validacion_rpm_20260923 import *
import shutil

data,audit=getdata();C=data['cij'];S=data['setup']
dem=pd.read_csv(OUT/'monte_carlo_demandas.csv',index_col=0).to_numpy()
assert len(list((OUT/'mc_logs').glob('*.json')))==1000
retry=[]
(OUT/'mc_intentos_iniciales').mkdir(exist_ok=True)
for s in range(1,1001):
    r=json.loads((OUT/'mc_logs'/f'{s:04d}.json').read_text())
    if not r['feasible']:
        for suffix in ['json','log']:
            shutil.copy2(OUT/'mc_logs'/f'{s:04d}.{suffix}',OUT/'mc_intentos_iniciales'/f'{s:04d}.{suffix}')
        rr=mc_job((s,C,dem[s-1],S,30));retry.append(s)
        print('Reintento',s,rr['feasible'],rr['gap_pct'],flush=True)
rows=[json.loads((OUT/'mc_logs'/f'{s:04d}.json').read_text()) for s in range(1,1001)]
df=pd.DataFrame(rows);df.to_csv(OUT/'monte_carlo_escenarios.csv',index=False)
v=df[df.feasible & (df.heuristica_faltantes==0)];lo=v.mejora_incumbente_pct;hi=v.mejora_cota_superior_pct
se=lo.std(ddof=1)/np.sqrt(len(lo));q=stats.t.ppf(.975,len(lo)-1)
result={'n':1000,'n_factibles_milp':int(df.feasible.sum()),'n_gap_cero':int(df.certified_zero_gap.sum()),'n_heuristica_infactible':int((df.heuristica_faltantes>0).sum()),'n_comparables':len(v),'mean_incumbent_improvement_pct':float(lo.mean()),'mean_optimal_improvement_upper_bound_pct':float(hi.mean()),'median_incumbent_pct':float(lo.median()),'sd_incumbent_pct':float(lo.std(ddof=1)),'min_incumbent_pct':float(lo.min()),'max_incumbent_pct':float(lo.max()),'max_gap_pct':float(df.gap_pct.max()),'mean_gap_pct':float(df.gap_pct.mean()),'seed':42,'matrix':'MODELO PL','time_limit_per_scenario':5,'target_gap_pct':.01,'n_positive_incumbent_improvement':int((lo>0).sum()),'ci95_mean_incumbent_pct':[float(lo.mean()-q*se),float(lo.mean()+q*se)],'escenarios_reintentados_30s':retry,'n_reintentados':len(retry),'nota':'Reintento solo de escenarios sin plan factible verificable al límite inicial. Logs iniciales preservados. Resumen de los 1000 escenarios, no solo óptimos.'}
savejson('monte_carlo_resumen.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
