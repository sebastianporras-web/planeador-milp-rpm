# Hallazgos del código y alcance de la revalidación

El código original se conserva sin modificaciones. La revalidación utiliza una traducción independiente de las mismas restricciones al MILP de SciPy/HiGHS.

## Hallazgos verificados

1. `resolver_asignacion` redondea las variables antes de calcular el residuo de integralidad. Esa comprobación no puede detectar fracciones del resultado original. La revalidación calcula residuos sobre X e Y sin redondear y comprueba también sus dominios.
2. El método de resolución original borra el archivo temporal de CBC al finalizar. La nueva corrida conserva logs por escenario y archivos JSON con estado, cotas y límites.
3. La función original de Monte Carlo calcula la mejora si existe objetivo y la heurística completa la demanda, sin condicionar explícitamente esa comparación a un control independiente de factibilidad del MILP. La nueva corrida exige factibilidad numérica verificada.
4. El resumen original de Monte Carlo usa únicamente escenarios certificados. Si la dificultad de resolución depende de la demanda, resumir solo ese subconjunto puede introducir selección. La revalidación conserva todos los escenarios factibles comparables y publica cotas de mejora, sin presentar incumbentes como óptimos.
5. El acceso `cargar_datos` utiliza MODELO PL. `construir_cij_con_imputacion` utiliza cronometrajes positivos e imputación por máquina. No son entradas equivalentes y deben distinguirse en texto y resultados.

## Controles realizados

- 99 identificadores únicos en la matriz y en la demanda nominal.
- Demanda nominal entera, no negativa y completa.
- Ambas matrices de 99 por 10 tienen valores finitos y positivos.
- Cobertura desde registros positivos: 819 posiciones observadas y 171 sin observación.
- Formulación diaria: 1.980 variables, 99 igualdades de demanda, 10 restricciones de capacidad y 990 enlaces.
- Pruebas pequeñas contrastadas con enumeración exhaustiva: dos casos factibles y uno infactible.
- Verificación sobre cantidades y activaciones sin redondear; tolerancia 1e-6 para residuos.
- Recalculado del plan multiperiodo guardado a partir de sus asignaciones, demanda y coeficientes.

## Límites

La existencia de registros numéricos no autentica mediciones de campo. Una ausencia de exceso de capacidad no certifica compatibilidad de moldes o materiales. Los datos de Excel se leen sin modificar ni recalcular sus fórmulas en Excel; la reconstrucción de cronometrajes se calcula directamente a partir de las 30 columnas numéricas.

Los resultados dependientes de tiempo pueden cambiar entre máquinas. Los archivos individuales conservados son el respaldo de la ejecución entregada. No se afirma una reproducción de la trayectoria interna de CBC ni una nueva ejecución de la interfaz Streamlit.
