from validacion_rpm_20260923 import *
import openpyxl

data,audit=getdata();C=data['cij'];D=demanda_entera(data['demanda']);S=data['setup']
w=SOURCE/'AnexodeDatosxlsx.xlsx'
final=pd.read_excel(w,sheet_name='DATOS FINALES',header=1,index_col=0).iloc[:,:10]
final.index=final.index.astype(str).str.strip();final=final.apply(pd.to_numeric,errors='coerce').reindex(C.index)/60
sim=pd.read_excel(w,sheet_name='DATOS SIMULADOS',header=1,index_col=0).iloc[:,:10]
sim.index=sim.index.astype(str).str.strip();sim=sim.apply(pd.to_numeric,errors='coerce').reindex(C.index)/60
fwb=openpyxl.load_workbook(w,read_only=True,data_only=False)
cwb=openpyxl.load_workbook(w,read_only=True,data_only=True)
raw_stats=[]
for j in MACHINES:
    raw=pd.read_excel(w,sheet_name='Datos '+j,header=1)
    names=raw.iloc[:,0].astype(str).str.strip()
    vals=raw.iloc[:,1:31].apply(pd.to_numeric,errors='coerce')
    for k,p in enumerate(names):
        if p not in C.index:continue
        v=vals.iloc[k]
        raw_stats.append({'referencia':p,'maquina':j,'fila_excel':k+3,'n_numericos':int(v.notna().sum()),'n_positivos':int((v>0).sum()),'n_ceros':int((v==0).sum()),'n_negativos':int((v<0).sum()),'media_incluye_ceros_min':float(v.mean()/60),'media_positivos_min':float(v[v>0].mean()/60),'publicada_min':float(C.loc[p,j]),'finales_cache_min':float(final.loc[p,j]),'promedio_formula':fwb['Datos '+j].cell(k+3,32).value})
raw_df=pd.DataFrame(raw_stats);raw_df.to_csv(OUT/'auditoria_cronometrajes.csv',index=False)
obs=audit['mask_observado'];details=[]
for p in C.index:
    row_obs=audit['cij_observada'].loc[p]
    for j in MACHINES:
        if abs(C.loc[p,j]-audit['cij'].loc[p,j])<=1e-6:continue
        rs=raw_df[(raw_df.referencia==p)&(raw_df.maquina==j)].iloc[0]
        cause='Ausencia de observación: valor publicado distinto de la media de máquina reconstruida; regla original no documentada'
        if obs.loc[p,j]:
            cause='Promedio publicado incluye ceros; reconstrucción usa solo tiempos positivos' if abs(C.loc[p,j]-rs.media_incluye_ceros_min)<1e-6 else 'Valor publicado no coincide con el promedio crudo: revisar traslado a DATOS SIMULADOS'
        details.append({'referencia':p,'maquina':j,'origen':cause,'n_positivos':rs.n_positivos,'n_ceros':rs.n_ceros,'publicada':C.loc[p,j],'reconstruida':audit['cij'].loc[p,j],'finales_cache':final.loc[p,j],'simulados':sim.loc[p,j]})
pd.DataFrame(details).to_csv(OUT/'causas_174_diferencias.csv',index=False)
mask=~obs
rowmean=audit['cij_observada'].mean(axis=1)
rm=pd.DataFrame(np.repeat(rowmean.to_numpy()[:,None],10,axis=1),index=C.index,columns=C.columns)
savejson('procedencia_resumen.json',{'celdas_publicada_igual_simulados_div60':int(((C-sim).abs()<1e-6).sum().sum()),'total':C.size,'171_imputadas_coinciden_media_maquina':int((((C-audit['cij']).abs()<1e-6)&mask).sum().sum()),'171_imputadas_coinciden_media_referencia':int((((C-rm).abs()<1e-6)&mask).sum().sum()),'observadas_con_ceros_y_diferencia':[r for r in details if r['n_positivos']>0],'total_registros_positivos_99':int(raw_df.n_positivos.sum()),'filas_sin_positivos_99':int((raw_df.n_positivos==0).sum())})
print(json.dumps(json.loads((OUT/'procedencia_resumen.json').read_text()),ensure_ascii=False),flush=True)

ext=cargar_datos_extendido(w)
cal=calibrar_demanda_extendida(D,ext['demanda'])
C=ext['cij'];S=ext['setup'];daily=cal['demanda_calibrada'];fixed=demanda_entera(daily,factor=3)
savejson('multiperiodo_datos.json',{'referencias':len(C),'factor_sesgo':cal['factor_sesgo'],'demanda_diaria_no_redondeada':float(daily.sum()),'demanda_fija_3_dias':int(fixed.sum()),'nota':'Comparar horizontes mínimos requiere conservar fija la demanda total. Se prueban también dos días con demanda proporcional al horizonte por separado.'})
for h in [1,2,3]:
    tag=f'multidia_lote_fijo_{h}dias'
    # Suma D_i min_j C_ij más un mínimo setup por referencia positiva es una cota inferior válida.
    lower=float((fixed*C.min(axis=1)).sum()+(fixed>0).sum()*S.min())
    if lower>h*10*1440:
        r={'status':2,'feasible':False,'lower_bound_analitica':lower,'capacidad_agregada':h*10*1440,'prueba':'Procesamiento mínimo más al menos un setup mínimo por referencia supera capacidad total','demanda_total':int(fixed.sum())}
        savejson(tag+'.json',r);print(tag,r,flush=True);continue
    r,X,Y,L=solve(C,fixed,S,days=h,limit=60,gap=.005,disp=True)
    r['demanda_total']=int(fixed.sum());export_solution(tag,C,fixed,S,r,X,Y,L)
ds=demanda_entera(daily,factor=2)
r,X,Y,L=solve(C,ds,S,days=2,limit=60,gap=.005,disp=True)
r['demanda_total']=int(ds.sum());export_solution('multidia_demanda_proporcional_2dias',C,ds,S,r,X,Y,L)
